#!/usr/bin/env python3
"""
Analyse d'un set ROM Hyper Neo Geo 64 pour preparer un portage "recomp" a la ReBuriki.

    python analyze_hng64_game.py --game sams64.zip --out work_sams64 [--name sams64]

Ce que ca fait (tout est lu depuis TES ROMs, rien n'est invente) :
  1. liste les fichiers du zip avec taille + CRC-32      -> profile.json (equivalent de GAME_ROMS)
  2. entrelace les 2 ROMs programme (pr01 + pr02) en image MIPS big-endian
     (meme methode que tools/install/build_from_rom.py de ReBuriki)
  3. lit l'en-tete de boot (+0x50 source, +0x54 destination, +0x58 nb de mots, +0x5C entree)
  4. decoupe le bloc de code -> <name>_code_80000000.bin
  5. produit des listes de graines pour Ghidra/N64Recomp :
       functions_seed.txt     "debut fin" par fonction (heuristiques, A VERIFIER dans Ghidra)
       extra_functions.txt    point d'entree du jeu
       kernel_candidates.txt  instructions COP0 que N64Recomp ne sait pas traduire
  6. affiche une carte de densite du code pour trouver ou le code s'arrete et ou les donnees commencent

Les champs d'en-tete sont ceux observes sur Buriki One. Pour un autre jeu ils sont a CONFIRMER
(voir le demarrage du BIOS en 0xBFC06444, cf. NOTES.md de ReBuriki).
"""
import argparse
import json
import os
import re
import struct
import sys
import zipfile

CART_BASE = 0x04000000      # le cartouche est mappe ici dans l'espace physique (NOTES.md de ReBuriki)
KSEG0 = 0x80000000
JR_RA = 0x03E00008
COP0_NAMES = {0: 'Index', 2: 'EntryLo0', 3: 'EntryLo1', 5: 'PageMask', 8: 'BadVAddr', 9: 'Count',
              10: 'EntryHi', 11: 'Compare', 12: 'Status', 13: 'Cause', 14: 'EPC', 15: 'PRId',
              16: 'Config', 28: 'TagLo', 30: 'ErrorEPC'}


def fail(msg):
    sys.exit("erreur: " + msg)


def find_program_roms(z, lo_name, hi_name):
    names = [i.filename for i in z.infolist()]

    def pick(explicit, pattern):
        if explicit:
            if explicit not in names:
                fail(f"{explicit} absent du zip. Fichiers: {', '.join(names)}")
            return explicit
        hits = sorted(n for n in names if re.search(pattern, os.path.basename(n), re.I))
        if not hits:
            fail(f"ROM programme '{pattern}' introuvable. Utilise --prog-lo/--prog-hi. Fichiers: {', '.join(names)}")
        return hits[0]
    return pick(lo_name, r'pro?0?1(?!\d)'), pick(hi_name, r'pro?0?2(?!\d)')


def interleave_be(lo, hi):
    """pr01 + pr02 entrelaces par 16 bits, lus en mots 32 bits little-endian, puis inverses en big-endian MIPS."""
    if len(lo) != len(hi):
        fail("les deux ROMs programme n'ont pas la meme taille")
    il = bytearray(len(lo) * 2)
    il[0::4], il[1::4], il[2::4], il[3::4] = lo[0::2], lo[1::2], hi[0::2], hi[1::2]
    n = len(il) // 4
    return struct.pack(">%dI" % n, *struct.unpack("<%dI" % n, il))


def be_words(buf):
    return struct.unpack(">%dI" % (len(buf) // 4), buf[:len(buf) // 4 * 4])


def classify_cop0(w):
    if w >> 26 != 0x10:
        return None
    rs, rd = (w >> 21) & 0x1F, (w >> 11) & 0x1F
    if rs in (0, 1, 4, 5):
        if rd == 12 and rs in (0, 4):
            return None                       # Status lu/ecrit: supporte par N64Recomp
        return '%s %s' % ({0: 'mfc0', 1: 'dmfc0', 4: 'mtc0', 5: 'dmtc0'}[rs], COP0_NAMES.get(rd, str(rd)))
    if rs == 0x10:
        return {0x18: 'eret', 0x01: 'tlbr', 0x02: 'tlbwi', 0x06: 'tlbwr', 0x08: 'tlbp'}.get(w & 0x3F, 'cop0 fn %x' % (w & 0x3F))
    return 'cop0 rs %x' % rs


# ---------------------------------------------------------------- mini-desassembleur MIPS (lecture de l'amorce)
REG = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7',
       's0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']
SPECIAL = {0x00: 'sll', 0x02: 'srl', 0x03: 'sra', 0x04: 'sllv', 0x06: 'srlv', 0x07: 'srav', 0x08: 'jr', 0x09: 'jalr',
           0x0C: 'syscall', 0x0D: 'break', 0x0F: 'sync', 0x10: 'mfhi', 0x12: 'mflo', 0x18: 'mult', 0x19: 'multu',
           0x1A: 'div', 0x1B: 'divu', 0x20: 'add', 0x21: 'addu', 0x22: 'sub', 0x23: 'subu', 0x24: 'and', 0x25: 'or',
           0x26: 'xor', 0x27: 'nor', 0x2A: 'slt', 0x2B: 'sltu'}
IMM = {0x08: 'addi', 0x09: 'addiu', 0x0A: 'slti', 0x0B: 'sltiu', 0x0C: 'andi', 0x0D: 'ori', 0x0E: 'xori'}
MEM = {0x20: 'lb', 0x21: 'lh', 0x23: 'lw', 0x24: 'lbu', 0x25: 'lhu', 0x28: 'sb', 0x29: 'sh', 0x2B: 'sw',
       0x31: 'lwc1', 0x39: 'swc1', 0x37: 'ld', 0x3F: 'sd'}


def disasm(w, pc):
    op, rs, rt, rd = w >> 26, (w >> 21) & 31, (w >> 16) & 31, (w >> 11) & 31
    sh, fn, imm = (w >> 6) & 31, w & 63, w & 0xFFFF
    simm = imm - 0x10000 if imm & 0x8000 else imm
    if w == 0:
        return 'nop'
    if op == 0:
        n = SPECIAL.get(fn)
        if n is None:
            return '.word 0x%08X' % w
        if n in ('jr',):
            return 'jr %s' % REG[rs]
        if n == 'jalr':
            return 'jalr %s, %s' % (REG[rd], REG[rs])
        if n in ('mfhi', 'mflo'):
            return '%s %s' % (n, REG[rd])
        if n in ('mult', 'multu', 'div', 'divu'):
            return '%s %s, %s' % (n, REG[rs], REG[rt])
        if n in ('sll', 'srl', 'sra'):
            return '%s %s, %s, %d' % (n, REG[rd], REG[rt], sh)
        if n in ('sllv', 'srlv', 'srav'):
            return '%s %s, %s, %s' % (n, REG[rd], REG[rt], REG[rs])
        if n in ('syscall', 'break', 'sync'):
            return n
        return '%s %s, %s, %s' % (n, REG[rd], REG[rs], REG[rt])
    if op in (2, 3):
        t = ((pc + 4) & 0xF0000000) | ((w & 0x3FFFFFF) << 2)
        return '%s 0x%08X' % ('j' if op == 2 else 'jal', t)
    if op in (4, 5, 6, 7):
        t = (pc + 4 + (simm << 2)) & 0xFFFFFFFF
        n = {4: 'beq', 5: 'bne', 6: 'blez', 7: 'bgtz'}[op]
        return ('%s %s, %s, 0x%08X' % (n, REG[rs], REG[rt], t)) if op in (4, 5) else ('%s %s, 0x%08X' % (n, REG[rs], t))
    if op == 1:
        t = (pc + 4 + (simm << 2)) & 0xFFFFFFFF
        n = {0: 'bltz', 1: 'bgez', 16: 'bltzal', 17: 'bgezal'}.get(rt)
        return ('%s %s, 0x%08X' % (n, REG[rs], t)) if n else '.word 0x%08X' % w
    if op in IMM:
        if op in (0x0C, 0x0D, 0x0E):
            return '%s %s, %s, 0x%X' % (IMM[op], REG[rt], REG[rs], imm)
        return '%s %s, %s, %d' % (IMM[op], REG[rt], REG[rs], simm)
    if op == 0x0F:
        return 'lui %s, 0x%X' % (REG[rt], imm)
    if op in MEM:
        return '%s %s, %d(%s)' % (MEM[op], REG[rt], simm, REG[rs])
    if op == 0x10:
        c = classify_cop0(w)
        if c:
            return '%s (cop0)  rt=%s' % (c, REG[rt])
        if rs == 0 and rd == 12:
            return 'mfc0 %s, Status' % REG[rt]
        if rs == 4 and rd == 12:
            return 'mtc0 %s, Status' % REG[rt]
        return 'cop0 0x%08X' % w
    return '.word 0x%08X' % w


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--game', required=True, help="zip MAME du jeu (ex. sams64.zip)")
    ap.add_argument('--out', required=True, help="dossier de travail (cree)")
    ap.add_argument('--name', help="nom court (defaut: nom du zip)")
    ap.add_argument('--prog-lo'); ap.add_argument('--prog-hi')
    ap.add_argument('--code-size', type=lambda x: int(x, 0), default=0x100000,
                    help="taille du bloc de code (defaut 0x100000 comme Buriki One; verifie avec la carte de densite)")
    ap.add_argument('--load-base', type=lambda x: int(x, 0),
                    help="force l'adresse virtuelle du debut du bloc de code (voir 'Base de chargement')")
    ap.add_argument('--list', nargs=2, metavar=('ROM_OFFSET', 'NB_MOTS'),
                    help="liste NB_MOTS instructions a partir de ROM_OFFSET (ex. --list 0x200 256 pour l'amorce); "
                         "ecrit aussi listing_<offset>.txt")
    ap.add_argument('--code-offset', type=lambda x: int(x, 0), help="force l'offset ROM du code (sinon: en-tete +0x50)")
    a = ap.parse_args()

    name = a.name or os.path.splitext(os.path.basename(a.game))[0]
    try:
        z = zipfile.ZipFile(a.game)
    except (OSError, zipfile.BadZipFile) as e:
        fail(f"{a.game} illisible: {e}")
    os.makedirs(a.out, exist_ok=True)

    files = [dict(name=i.filename, size=i.file_size, crc="0x%08X" % i.CRC) for i in z.infolist() if not i.is_dir()]
    lo_n, hi_n = find_program_roms(z, a.prog_lo, a.prog_hi)
    be = interleave_be(z.read(lo_n), z.read(hi_n))
    print(f"ROMs programme: {lo_n} + {hi_n} -> image de {len(be) >> 20} Mo ({len(be):#x} octets)")

    W = be_words(be[:0x100])
    title = be[0:0x20].split(b'\0')[0].decode('ascii', 'replace')
    magic = be[0x60:0x70].split(b'\0')[0].decode('ascii', 'replace')
    src, dst, count, entry = W[0x50 // 4], W[0x54 // 4], W[0x58 // 4], W[0x5C // 4]
    print(f"En-tete: titre={title!r} marqueur={magic!r}")
    print(f"  +0x50 source=0x{src:08X}  +0x54 destination=0x{dst:08X}  +0x58 mots=0x{count:X}  +0x5C entree=0x{entry:08X}")
    warn = []
    if 'NEOGEO64' not in magic.replace(' ', '').upper():
        warn.append("marqueur 'HYPER NEOGEO64' absent a 0x60: l'en-tete n'a peut-etre pas le meme format")
    if not (CART_BASE <= src < CART_BASE + 0x2000000):
        warn.append("la source ne tombe pas dans la fenetre cartouche 0x04000000-0x05FFFFFF")
    if not (KSEG0 <= entry < KSEG0 + 0x1000000):
        warn.append("l'entree n'est pas dans la RAM KSEG0: champs a reverifier dans le boot du BIOS")
    if count * 4 < 0x10000:
        warn.append(f"le BIOS ne copie que 0x{count * 4:X} octets (en-tete +0x58): c'est une amorce; le reste du jeu est "
                    "probablement charge par le code du jeu lui-meme. L'adresse de chargement ci-dessous est une SUPPOSITION: "
                    "voir la section 'Base de chargement'")
    for w in warn:
        print("  ATTENTION:", w)

    code_off = a.code_offset if a.code_offset is not None else src - CART_BASE
    if not (0 <= code_off < len(be)):
        fail(f"offset de code 0x{code_off:X} hors de l'image; utilise --code-offset")
    code_vram = KSEG0 | dst
    code = be[code_off:code_off + a.code_size]
    code_path = os.path.join(a.out, f"{name}_code_{code_vram:08x}.bin")
    open(code_path, 'wb').write(code)
    print(f"Code: ROM 0x{code_off:X}..0x{code_off + len(code):X} -> vram 0x{code_vram:08X}  ({code_path})")

    W = be_words(code)
    n = len(W)

    # ---- base de chargement: la bonne est celle ou les cibles des 'jal' tombent sur des debuts de fonctions.
    # Test exact (pas de 4 octets): pour chaque couple (cible, debut de fonction), la base candidate est cible - debut.
    from collections import Counter
    rel_list = []
    for i in range(n):
        if W[i] == JR_RA:
            j = i + 2
            while j < n and W[j] == 0:
                j += 1
            if j < n:
                rel_list.append(j * 4)
    rel_list = sorted(set(rel_list) | {0})
    targets = sorted({((w & 0x3FFFFFF) << 2) & 0x0FFFFFFF for w in W if w >> 26 == 3})
    RAM_END = 0x01000000                                  # 16 Mo de RAM principale
    cnt = Counter()
    for t in targets:
        for s_off in rel_list:
            b = t - s_off
            if 0 <= b < RAM_END:
                cnt[b] += 1
    print(f"\nBase de chargement (cibles jal sur debuts de fonctions; {len(targets)} cibles distinctes, ReBuriki: ~83% sur Buriki One):")
    top = cnt.most_common(5)
    for b, hits in top:
        print(f"  base 0x{KSEG0 | b:08X}: {hits}/{len(targets)} = {100 * hits / max(1, len(targets)):.0f}%")
    found_base = KSEG0 | top[0][0] if top else None
    if found_base is not None and found_base != code_vram:
        print(f"  -> la meilleure base (0x{found_base:08X}) differe de celle de l'en-tete (0x{code_vram:08X}).")
        print(f"     Si le pourcentage est eleve, relance avec:  --load-base 0x{found_base:08X}")

    # Meme test par morceaux de 64 Ko: un code charge en plusieurs blocs montre des bases differentes.
    print("\nBase par morceau de 64 Ko (si elle change d'un morceau a l'autre, le code est charge en plusieurs blocs):")
    CH = 0x10000
    for c0 in range(0, n * 4, CH):
        sub = [x for x in rel_list if c0 <= x < c0 + CH]
        if len(sub) < 20:
            continue
        cc = Counter()
        for t in targets:
            for s_off in sub:
                b = t - s_off
                if 0 <= b < RAM_END:
                    cc[b] += 1
        b, hits = cc.most_common(1)[0]
        print(f"  +0x{c0:06X}: base 0x{KSEG0 | b:08X}  ({hits} appels sur {len(sub)} fonctions du morceau; "
              f"debut du morceau -> 0x{KSEG0 | (b + c0):08X})")
    if a.load_base is not None:
        code_vram = a.load_base
        print(f"  (base forcee par --load-base: 0x{code_vram:08X})")

    if a.list:
        lo_off, cnt_w = int(a.list[0], 0), int(a.list[1], 0)
        stub_lo, stub_hi = src - CART_BASE, src - CART_BASE + count * 4
        lines = []
        for i in range(cnt_w):
            ro = lo_off + i * 4
            if ro + 4 > len(be):
                break
            if stub_lo <= ro < stub_hi:                   # zone copiee par le BIOS a l'adresse de l'en-tete
                pc, tag = (KSEG0 | dst) + (ro - stub_lo), 'amorce'
            else:                                         # zone du code, selon la base choisie (--load-base)
                pc, tag = code_vram + (ro - code_off), 'code'
            w = struct.unpack('>I', be[ro:ro + 4])[0]
            lines.append('%08X  rom+%06X  %08X  %-6s %s' % (pc, ro, w, tag, disasm(w, pc)))
        text = '\n'.join(lines)
        path = os.path.join(a.out, 'listing_%X.txt' % lo_off)
        open(path, 'w').write(text + '\n')
        print(f"\nListing de {len(lines)} instructions -> {path}\n" + text + "\n")

    # ---- graines de fonctions
    starts = set()
    for i in range(n):
        if W[i] == JR_RA:
            j = i + 2
            while j < n and W[j] == 0:
                j += 1
            if j < n:
                starts.add(code_vram + j * 4)
    for w in W:
        if w >> 26 == 3:                                   # jal
            t = ((w & 0x3FFFFFF) << 2) | (code_vram & 0xF0000000)
            if code_vram <= t < code_vram + len(code):
                starts.add(t)
    if code_vram <= entry < code_vram + len(code):
        starts.add(entry)
    st = sorted(starts)
    with open(os.path.join(a.out, 'functions_seed.txt'), 'w') as f:
        for k, s in enumerate(st):
            e = st[k + 1] if k + 1 < len(st) else code_vram + len(code)
            f.write('%08x %08x\n' % (s, e))
    with open(os.path.join(a.out, 'extra_functions.txt'), 'w') as f:
        f.write("# point d'entree du jeu (en-tete +0x5C), a confirmer\n%08x\n" % entry)
    print(f"Graines: {len(st)} fonctions (heuristique, a affiner avec Ghidra: tools/ghidra_scripts/SeedAndExport.java)")

    # ---- fonctions "noyau" candidates
    kern = {}
    for i, w in enumerate(W):
        c = classify_cop0(w)
        if c:
            va = code_vram + i * 4
            fs = max((s for s in st if s <= va), default=None)
            kern.setdefault(fs, set()).add(c)
    with open(os.path.join(a.out, 'kernel_candidates.txt'), 'w') as f:
        for fs, ins in sorted(kern.items(), key=lambda kv: (kv[0] is None, kv[0])):
            label = 'func_%08X' % fs if fs is not None else '(avant la 1ere fonction)'
            f.write('%s: %s\n' % (label, ', '.join(sorted(ins))))
    print(f"Candidates noyau: {len(kern)} (a mettre dans [patches] ignored + kernel.cpp)")

    # ---- carte de densite par blocs de 64 Ko
    print("\nDensite par bloc de 64 Ko (prologues 'addiu sp,sp,-N' / jal / jr ra). Le code s'arrete la ou ca tombe a ~0:")
    blk = 0x10000 // 4
    last_code = 0
    for b in range(0, n, blk):
        seg = W[b:b + blk]
        pro = sum(1 for w in seg if (w >> 16) == 0x27BD and (w & 0x8000))
        jal = sum(1 for w in seg if w >> 26 == 3)
        ret = sum(1 for w in seg if w == JR_RA)
        if pro >= 8:
            last_code = b * 4 + 0x10000
        print(f"  +0x{b * 4:06X}: prologues={pro:4d} jal={jal:4d} jr_ra={ret:4d}")
    print(f"Estimation grossiere de la fin du code: +0x{last_code:X} (verifie dans Ghidra)")

    final_path = os.path.join(a.out, f"{name}_code_{code_vram:08x}.bin")
    if final_path != code_path:
        os.replace(code_path, final_path)
        code_path = final_path
    profile = dict(name=name, game_zip=os.path.basename(a.game), program_roms=[lo_n, hi_n], files=files,
                   header=dict(title=title, marker=magic, source=src, destination=dst, words=count, entry=entry),
                   code=dict(rom_offset=code_off, size=len(code), vram=code_vram, image=os.path.basename(code_path)),
                   warnings=warn)
    json.dump(profile, open(os.path.join(a.out, 'profile.json'), 'w'), indent=2)
    print(f"\nProfil ecrit: {os.path.join(a.out, 'profile.json')}")


if __name__ == '__main__':
    main()
