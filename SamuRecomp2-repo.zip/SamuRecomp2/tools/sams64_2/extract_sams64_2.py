#!/usr/bin/env python3
"""
Extraction des segments de Samurai Shodown 64: Warriors Rage (sams64_2) a partir de TA ROM.

    python3 tools/sams64_2/extract_sams64_2.py --game ~/Downloads/sams64_2.zip --out work

Carte memoire decodee du crt0 (ROM 0x200-0x440), voir docs/BOOT_PLAN_sams64_2.md. Le script verifie d'abord les
instructions du crt0 aux memes offsets (sinon: autre revision).
Sorties dans --out:
  sams64_2_image_80100000.bin  memoire du jeu 0x80100000-0x802FDB50 (code+donnees, trous a zero) lue par N64Recomp
  sams64_2_text_80100000.bin   code seul 0x80100000-0x8019ECF0
  sams64_2_stub_80001000.bin   amorce (ROM 0x200 -> 0x80001000)
  functions_text.txt / functions_stub.txt / kernel_candidates.txt / segments.json
"""
import argparse, json, os, sys, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analyze_hng64_game import JR_RA, be_words, classify_cop0, find_program_roms, interleave_be  # noqa: E402

SANITY = [(0x200, 0x3C1D8001), (0x204, 0x27BD8000), (0x208, 0x3C1C802F), (0x20C, 0x279C7FD8), (0x2A0, 0x3C05802F),
          (0x2A4, 0x24A52B10), (0x2A8, 0x3C040001), (0x2AC, 0x2484B040), (0x2D4, 0x3C05A401), (0x2D8, 0x24A5B550),
          (0x2DC, 0x3C048010), (0x2E4, 0x3C03000C), (0x2E8, 0x24637130), (0x294, 0x3C06A400), (0x298, 0x24C60510),
          (0x3D8, 0x3C04000F), (0x3DC, 0x24842B04), (0x408, 0x8F823248)]

SEGMENTS = [
    dict(name='stub', rom=0x200, size=0x1000, vram=0x80001000, by='BIOS (en-tete)', note='crt0, test RAM, vecteurs'),
    dict(name='dataA', rom=0x510, size=0xB040, vram=0x802F2B10, by='crt0', note='donnees (autour de gp)'),
    dict(name='game', rom=0xB550, size=0xC7130, vram=0x80100000, by='crt0', note='gestionnaire d\'exceptions (0x80100000), code, donnees'),
]
ZERO = dict(vram=0x80200000, size=0xF2B04)   # mis a zero par le crt0 (0x80200000..0x802F2B04)
SP, GP = 0x80008000 - 48, 0x802F7FD8
MAIN_PTR = 0x802FB220                         # 'lw v0, 0x3248(gp); jalr v0' a la fin du crt0
CODE_LO, CODE_HI = 0x80100000, 0x8019ECF0     # dernier 'jr ra' a 0x8019ECE4 (+ delay slot)
STUB_FUNCS = [(0x80001000, 0x80001224), (0x80001224, 0x8000122C), (0x8000122C, 0x80001248),
              (0x80001248, 0x800012D8), (0x800012D8, 0x800012E0)]
EXTRA_STARTS = []
# Patches applies a la copie traduite (jamais a ta ROM): N64Recomp refuse 'cfc1 a1, $0' (FIR). La fonction func_80100D3C
# sauvegarde le contexte FPU d'un thread; FIR n'est qu'une valeur sauvegardee, on lit FCSR ($31) a la place.
PATCHES = [(0x80100EB0, 0x44450000, 0x4445F800)]


def fail(m):
    sys.exit("erreur: " + m)


def seeds(words, base, lo, hi, extra=()):
    n = len(words); st = set(extra)
    for i in range(n):
        if words[i] == JR_RA:
            j = i + 2
            while j < n and words[j] == 0:
                j += 1
            if j < n:
                st.add(base + j * 4)
    for w in words:
        if w >> 26 == 3:
            t = ((w & 0x3FFFFFF) << 2) | (base & 0xF0000000)
            if lo <= t < hi:
                st.add(t)
    st = sorted(x for x in st if lo <= x < hi)
    return [(s, st[k + 1] if k + 1 < len(st) else hi) for k, s in enumerate(st)]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--game', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    z = zipfile.ZipFile(os.path.expanduser(a.game))
    be = interleave_be(z.read('005pr01a.81'), z.read('005pr02a.82'))
    bad = [(o, e, int.from_bytes(be[o:o + 4], 'big')) for o, e in SANITY if int.from_bytes(be[o:o + 4], 'big') != e]
    if bad:
        for o, e, g in bad[:6]:
            print(f"  ROM 0x{o:X}: attendu {e:08X}, trouve {g:08X}")
        fail("controle du crt0 en echec: ce n'est pas la ROM dont la carte a ete decodee")
    print(f"Controle du crt0: {len(SANITY)}/{len(SANITY)} instructions identiques.")
    os.makedirs(a.out, exist_ok=True)
    seg = {s['name']: s for s in SEGMENTS}
    base = seg['game']['vram']
    end = seg['dataA']['vram'] + seg['dataA']['size']
    image = bytearray(end - base)
    for n in ('game', 'dataA'):
        s = seg[n]
        image[s['vram'] - base:s['vram'] - base + s['size']] = be[s['rom']:s['rom'] + s['size']]
    for va, old, new in PATCHES:
        o = va - base
        if int.from_bytes(image[o:o + 4], 'big') != old:
            fail("patch 0x%08X: instruction inattendue" % va)
        image[o:o + 4] = new.to_bytes(4, 'big')
    open(os.path.join(a.out, 'sams64_2_image_%08X.bin' % base), 'wb').write(image)
    text = bytes(image[CODE_LO - base:CODE_HI - base])
    open(os.path.join(a.out, 'sams64_2_text_%08X.bin' % CODE_LO), 'wb').write(text)
    open(os.path.join(a.out, 'sams64_2_stub_80001000.bin'), 'wb').write(be[0x200:0x1200])
    mp = int.from_bytes(image[MAIN_PTR - base:MAIN_PTR - base + 4], 'big')
    tw = be_words(text)
    ts = seeds(tw, CODE_LO, CODE_LO, CODE_HI, extra=[mp, CODE_LO] + EXTRA_STARTS)
    with open(os.path.join(a.out, 'functions_text.txt'), 'w') as f:
        for s, e in ts:
            f.write('%08x %08x\n' % (s, e))
    with open(os.path.join(a.out, 'functions_stub.txt'), 'w') as f:
        for s, e in STUB_FUNCS:
            f.write('%08x %08x\n' % (s, e))
    json.dump(dict(segments=SEGMENTS, zero=ZERO, sp=SP, gp=GP, main=mp, entry=0x80001000,
                   exception_handler=0x80100000), open(os.path.join(a.out, 'segments.json'), 'w'), indent=2)
    starts = [s for s, _ in ts]; kern = {}
    for i, w in enumerate(tw):
        c = classify_cop0(w) or ('cache' if w >> 26 == 0x2F else None)
        if c:
            va = CODE_LO + i * 4
            fs = max((s for s in starts if s <= va), default=None)
            kern.setdefault(fs, set()).add(c)
    with open(os.path.join(a.out, 'kernel_candidates.txt'), 'w') as f:
        for fs, ins in sorted(kern.items(), key=lambda kv: (kv[0] is None, kv[0])):
            f.write('%s: %s\n' % ('func_%08X' % fs if fs else '?', ', '.join(sorted(ins))))
    print(f"Code 0x{CODE_LO:08X}..0x{CODE_HI:08X}, image 0x{base:08X}..0x{end:08X} ({len(image) >> 10} Ko)")
    print(f"main = 0x{mp:08X}: {'present' if mp in set(starts) else 'ABSENT'} parmi les graines")
    print(f"Fonctions (graines): {len(ts)}; candidates noyau: {len(kern)}")
    for fs, ins in sorted(kern.items(), key=lambda kv: (kv[0] is None, kv[0])):
        print(f"  {'func_%08X' % fs if fs else '?'}: {', '.join(sorted(ins))}")
    print(f"Ecrit dans {a.out}")


if __name__ == '__main__':
    main()
