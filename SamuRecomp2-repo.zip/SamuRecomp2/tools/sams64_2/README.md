# Samurai Shodown 64: Warriors Rage (sams64_2) — port in progress

Status: boots, runs in colour from the warning screen through attract mode, title, character select and a full 3D fight (headless run, 9000 frames). Sound and real-time play untested.

1. `python3 tools/sams64_2/unpack_roms_sams64_2.py --fork . --game sams64_2.zip --bios hng64.zip`
2. `python3 tools/sams64_2/extract_sams64_2.py --game ~/Downloads/sams64_2.zip --out work`

First analysis: header "SAMURAI SPIRITS 64  Ver 2", crt0 at 0x80001000, main code ~0xB0000 bytes, probable load base 0x800F4CB0 (95% of jal targets), ~3291 function seeds. Memory map, kernel functions and runtime patches still to do (see ../../docs/BOOT_PLAN.md for the method used on the first game).

3. `python3.11 tools/sams64_2/translate_sams64_2.py --fork . --game sams64_2.zip --n64recomp ~/N64Recomp`
4. `python3.11 tools/sams64_2/build_sams64_2_linux.py --fork . --n64recomp ~/N64Recomp`
5. `WINEPREFIX=~/.wine-ss64 wine build/samurecomp.exe --roms roms`
