"""Sections a recompiler pour Samurai Shodown 64: Warriors Rage (a copier sur tools/sections.py du fork).
Carte decodee du crt0 (docs/BOOT_PLAN_sams64_2.md):
  .text  jeu (gestionnaire d'exceptions + code)  0x80100000..0x8019ECF0   (ROM 0xB550..)
  .stub  amorce / crt0                           0x80001000..0x800012E0   (ROM 0x200..)
L'image .text va de 0x80100000 a 0x802FDB50 (code, donnees, trou a zero, donnees autour de gp) pour que N64Recomp
retrouve les tables de sauts. Pas de section .low: les vecteurs (0x80000000/80/180/800) ne font que sauter a 0x80100000.
"""
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.environ.get('BURIKI_WORK') or os.path.join(ROOT, 'work')


def p(*parts):
    return os.path.join(ROOT, *parts)


def w(name):
    return os.path.join(WORK, name)


SECTIONS = [
    dict(name='.text', image=w('sams64_2_image_80100000.bin'), vram=0x80100000,
         funcs=p('tools', 'data', 'functions_text_sams64_2.txt'), extra=None,
         lo=0x80100000, hi=0x8019ECF0),
    dict(name='.stub', image=w('sams64_2_stub_80001000.bin'), vram=0x80001000,
         funcs=p('tools', 'data', 'functions_stub_sams64_2.txt'), extra=None,
         lo=0x80001000, hi=0x800012E0),
]

COMBINED_ROM = w('recomp_rom.bin')
