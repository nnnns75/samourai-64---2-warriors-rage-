#!/usr/bin/env python3
"""
Compile le portage SS64 sous Linux (distrobox/Ubuntu) en un .exe Windows, avec llvm-mingw.

    python3.11 build_sams64_linux.py --fork ~/SamuRecomp --n64recomp ~/N64Recomp

Prerequis: la traduction est faite (translate_sams64_2.py) et le runtime est adapte ((runtime deja adapte dans ce depot)).
Le script telecharge llvm-mingw (une fois) dans ~/llvm-mingw, genere recomp.h et func_table.cpp, compile tout
en parallele, puis lie <fork>/build/samurecomp.exe. Relancer reprend: les .o deja a jour sont gardes.
"""
import argparse
import concurrent.futures
import json
import os
import subprocess
import sys
import tarfile
import urllib.request

LIBS = ["user32", "gdi32", "winmm", "d3d11", "dxgi", "ole32", "ws2_32", "shell32"]
SUBDIRS = ["iomcu", "audiocpu", "frontend"]
CXX = "x86_64-w64-mingw32-clang++"


def toolchain(home):
    root = os.path.join(home, "llvm-mingw")
    cxx = os.path.join(root, "bin", CXX)
    if os.path.exists(cxx):
        return cxx
    print("Telechargement de llvm-mingw (environ 200 Mo)...")
    rel = json.load(urllib.request.urlopen("https://api.github.com/repos/mstorsjo/llvm-mingw/releases/latest"))
    url = next((a["browser_download_url"] for a in rel["assets"]
                if "ucrt-ubuntu" in a["name"] and a["name"].endswith("x86_64.tar.xz")), None)
    if not url:
        sys.exit("erreur: archive llvm-mingw ubuntu x86_64 introuvable dans la derniere release")
    tgz = os.path.join(home, "llvm-mingw.tar.xz")
    urllib.request.urlretrieve(url, tgz)
    with tarfile.open(tgz) as t:
        top = t.getnames()[0].split("/")[0]
        t.extractall(home)
    os.rename(os.path.join(home, top), root)
    os.remove(tgz)
    return cxx


def run(cmd, **kw):
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace", **kw)
    if p.returncode:
        sys.exit(f"erreur: {' '.join(cmd[:3])}...\n{p.stdout[-3000:]}")
    return p.stdout


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fork", required=True)
    ap.add_argument("--n64recomp", required=True)
    ap.add_argument("--jobs", type=int, default=0)
    a = ap.parse_args()
    fork = os.path.abspath(os.path.expanduser(a.fork))
    n64 = os.path.abspath(os.path.expanduser(a.n64recomp))
    rt = os.path.join(fork, "recomp", "runtime")
    gen = os.path.join(fork, "recomp", "generated")
    tools = os.path.join(fork, "tools")
    build = os.path.join(fork, "build")
    hdr = os.path.join(build, "gen_runtime")
    odir = os.path.join(build, "obj")
    os.makedirs(hdr, exist_ok=True)
    os.makedirs(odir, exist_ok=True)
    if not os.path.isdir(gen) or not os.path.exists(os.path.join(gen, "funcs.h")):
        sys.exit("erreur: code C traduit absent (lance d'abord translate_sams64_2.py)")
    if not os.path.exists(os.path.join(rt, "kernel_sams64_2.cpp")):
        sys.exit("erreur: runtime non adapte (lance (runtime deja adapte dans ce depot))")

    cxx = toolchain(os.path.expanduser("~"))
    print("1/4 en-tete recomp.h et table des fonctions")
    run([sys.executable, os.path.join(tools, "make_recomp_header.py"), os.path.join(n64, "include", "recomp.h"),
         os.path.join(rt, "recomp_mem_section.txt"), os.path.join(hdr, "recomp.h")])
    run([sys.executable, os.path.join(tools, "make_func_table.py"), os.path.join(fork, "recomp", "sams64_2.syms.toml"),
         os.path.join(hdr, "func_table.cpp")])
    # Le code traduit de SS64 appelle DMULT avec des uint64_t (lo, hi) ; recomp.h n'accepte que int64_t*.
    hp = os.path.join(hdr, "recomp.h")
    h = open(hp, encoding="utf-8").read()
    marker = "static inline uint32_t get_cop1_cs()"
    if "SAMS64_DMULT_OVERLOAD" not in h:
        if h.count(marker) != 1:
            sys.exit("erreur: recomp.h a une forme inattendue")
        h = h.replace(marker, """// SAMS64_DMULT_OVERLOAD
static inline void DMULT(int64_t a, int64_t b, uint64_t* lo64, uint64_t* hi64) {
    int64_t l, h;
    DMULT(a, b, &l, &h);
    *lo64 = (uint64_t)l;
    *hi64 = (uint64_t)h;
}

""" + marker)
        open(hp, "w", encoding="utf-8", newline="\n").write(h)

    tasks = [(os.path.join(gen, f), "gen_" + f, "-O1") for f in sorted(os.listdir(gen))
             if f.startswith("funcs_") and f.endswith(".c")]
    tasks.append((os.path.join(hdr, "func_table.cpp"), "func_table.cpp", "-O2"))
    for sub in [""] + SUBDIRS:
        d = os.path.join(rt, sub)
        tasks += [(os.path.join(d, f), (sub or "rt") + "_" + f, "-O2") for f in sorted(os.listdir(d)) if f.endswith(".cpp")]
    tasks.sort(key=lambda t: -os.path.getsize(t[0]))
    ram = 8
    try:
        ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2**30
    except (ValueError, OSError):
        pass
    jobs = a.jobs or max(1, min(os.cpu_count() or 2, int(ram / 1.5)))
    inc = ["-I", rt, "-I", hdr, "-I", gen]
    # le dernier mtime des en-tetes decide si un .o est a refaire
    newest_h = max(os.path.getmtime(os.path.join(r, f)) for r in (rt, hdr, gen) for f in os.listdir(r) if f.endswith(".h"))

    def one(t):
        src, name, opt = t
        obj = os.path.join(odir, name + ".o")
        if os.path.exists(obj) and os.path.getmtime(obj) > max(os.path.getmtime(src), newest_h):
            return src, obj, 0, ""
        p = subprocess.run([cxx, "-x", "c++", "-std=c++20", opt, "-w"] + inc + ["-c", src, "-o", obj],
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace")
        return src, obj, p.returncode, p.stdout

    print(f"2/4 compilation de {len(tasks)} fichiers ({jobs} en parallele)")
    objs, bad, done = [], [], 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=jobs) as ex:
        for f in concurrent.futures.as_completed([ex.submit(one, t) for t in tasks]):
            src, obj, rc, out = f.result()
            done += 1
            if rc:
                bad.append(src)
                print(f"\n--- ECHEC {os.path.basename(src)} ---\n{out[:2500]}")
            else:
                objs.append(obj)
            print(f"\r  {done}/{len(tasks)}", end="", flush=True)
    print()
    if bad:
        sys.exit(f"{len(bad)} fichier(s) en echec: " + ", ".join(os.path.basename(b) for b in bad))

    print("3/4 edition de liens")
    exe = os.path.join(build, "samurecomp.exe")
    rsp = os.path.join(build, "link.rsp")
    open(rsp, "w").write("".join(f'"{o}"\n' for o in objs))
    run([cxx, "-O2", "-static", "@" + rsp, "-o", exe] + ["-l" + l for l in LIBS])
    print(f"4/4 OK: {exe}")


if __name__ == "__main__":
    main()
