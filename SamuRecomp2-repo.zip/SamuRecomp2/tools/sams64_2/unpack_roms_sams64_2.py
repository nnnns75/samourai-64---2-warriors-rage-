#!/usr/bin/env python3
"""
Extrait de TES zips MAME les fichiers dont le portage a besoin, dans <fork>/roms/sams64_2 et <fork>/roms/hng64.

    python3 unpack_roms_sams64_2.py --fork ~/SamuRecomp2-repo --game sams64_2.zip --bios hng64.zip

Les fichiers sont retrouves par taille et CRC-32 (pas par nom: un set MAME range les textures identiques sous un seul
nom, ex. 002-tx01a.13 pour 002-tx01a.1), puis ecrits sous le nom canonique que le moteur attend. Les CRC sont ceux du set sams64_2 de MAME (releves sur un dump valide, a confirmer):
si l'un differe, le script s'arrete (autre revision du jeu). Rien de ce qui est ecrit ici ne doit etre publie.
"""
import argparse
import os
import sys
import zipfile
import zlib

GAME_ROMS = [   # (nom, taille, CRC-32) lus dans un dump MAME de sams64_2 (Samurai Shodown 64: Warriors Rage); textures: 1 copie sur 4 (identiques)
    ("005pr01a.81", 0x400000, 0xA69D7700),
    ("005pr02a.82", 0x400000, 0x38B9E6B3),
    ("005pr03a.83", 0x400000, 0x0BC738A8),
    ("005pr04a.84", 0x400000, 0x6B504852),
    ("005pr05a.85", 0x400000, 0x32A743D3),
    ("005pr06a.86", 0x400000, 0xC09FA615),
    ("005pr07a.87", 0x400000, 0x44286AD3),
    ("005pr08a.88", 0x400000, 0xD094EB67),
    ("005sc01a.97", 0x800000, 0x7F11CDA9),
    ("005sc02a.99", 0x800000, 0x87D1E1A7),
    ("005sc03a.101", 0x800000, 0xA5D4C535),
    ("005sc04a.103", 0x800000, 0x14930D77),
    ("005sc05a.98", 0x800000, 0x4475A3F8),
    ("005sc06a.100", 0x800000, 0x41C0FBBD),
    ("005sc07a.102", 0x800000, 0x3505B198),
    ("005sc08a.104", 0x800000, 0x3139E413),
    ("005sd01a.77", 0x400000, 0x8F68150F),
    ("005sd02a.78", 0x400000, 0x6B4DA6A0),
    ("005sd03a.79", 0x400000, 0xA529FAB3),
    ("005sd04a.80", 0x400000, 0xDCA95EAD),
    ("005sp01a.105", 0x800000, 0x68EEFEE5),
    ("005sp02a.109", 0x800000, 0x5D9A49B9),
    ("005sp03a.113", 0x800000, 0x9B6530FE),
    ("005sp04a.117", 0x800000, 0xD4E422CE),
    ("005sp05a.106", 0x400000, 0xD8B1FB26),
    ("005sp06a.110", 0x400000, 0x87ED72A0),
    ("005sp07a.114", 0x400000, 0x8EB3C173),
    ("005sp08a.118", 0x400000, 0x05486FBC),
    ("005tx01a.1", 0x400000, 0x05A4CEB7),
    ("005tx02a.2", 0x400000, 0xB7094C69),
    ("005tx03a.3", 0x400000, 0x34764891),
    ("005tx04a.4", 0x400000, 0x6BE50882),
    ("005vt01a.17", 0x400000, 0x48A61479),
    ("005vt02a.18", 0x400000, 0xBA9100C8),
    ("005vt03a.19", 0x400000, 0xF54A28DE),
    ("005vt04a.20", 0x400000, 0x57AD79C7),
    ("005vt05a.21", 0x400000, 0x49C82BEC),
    ("005vt06a.22", 0x400000, 0x7BA05B6C),
]

SYSTEM_ROMS = [   # (nom, taille, CRC-32, obligatoire) comme tools/install/build_from_rom.py de ReBuriki
    ("brom1.bin", 0x80000, 0xA30DD3DE, True),          # BIOS Japon (le code du jeu a ete lu avec celui-ci)
    ("tmp87ph40an.bin", 0x8000, 0xB70DF21F, True),     # microcontroleur de la carte d'E/S
    ("bios_us.bin", 0x80000, 0xAB5948D6, False),
    ("bios_export.bin", 0x80000, 0xBBF07EC6, False),
    ("bios_korea.bin", 0x80000, 0xAC953E2E, False),
]


def index(path):
    try:
        z = zipfile.ZipFile(path)
    except (OSError, zipfile.BadZipFile) as e:
        sys.exit(f"erreur: {path} illisible ({e})")
    return z, {(i.file_size, i.CRC): i for i in z.infolist() if not i.is_dir()}


def extract(z, info, out, crc):
    os.makedirs(os.path.dirname(out), exist_ok=True)
    c = 0
    with z.open(info) as s, open(out, "wb") as d:
        while True:
            b = s.read(1 << 20)
            if not b:
                break
            c = zlib.crc32(b, c)
            d.write(b)
    if c != crc:
        sys.exit(f"erreur: {os.path.basename(out)} est corrompu dans le zip")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--fork", required=True)
    ap.add_argument("--game", required=True)
    ap.add_argument("--bios", required=True)
    a = ap.parse_args()
    gz, gi = index(a.game)
    bz, bi = index(a.bios)
    missing = [n for n, s, c in GAME_ROMS if (s, c) not in gi]
    if missing:
        sys.exit(f"erreur: {len(missing)} fichier(s) manquants ou differents dans {os.path.basename(a.game)}: "
                 + ", ".join(missing[:6]) + (" ..." if len(missing) > 6 else ""))
    miss = [n for n, s, c, req in SYSTEM_ROMS if req and (s, c) not in bi]
    if miss:
        sys.exit(f"erreur: {os.path.basename(a.bios)} ne contient pas: {', '.join(miss)}")
    for n, s, c in GAME_ROMS:
        extract(gz, gi[(s, c)], os.path.join(a.fork, "roms", "sams64_2", n), c)
    for n, s, c, req in SYSTEM_ROMS:
        if (s, c) in bi:
            extract(bz, bi[(s, c)], os.path.join(a.fork, "roms", "hng64", n), c)
        else:
            print(f"note: {n} absent (region de repli: Japon)")
    print(f"OK: {len(GAME_ROMS)} fichiers du jeu et le BIOS dans {os.path.join(a.fork, 'roms')}")


if __name__ == "__main__":
    main()
