// Samurai Shodown 64: hand-written replacements for what N64Recomp can't translate
// (see recomp/sams64_2.toml [patches] ignored, and BOOT_PLAN_sams64_2.md). Mirrors runtime/kernel.h of ReBuriki (MIT).
#ifndef SAMS64_2_KERNEL_H
#define SAMS64_2_KERNEL_H

#include "recomp.h"

#ifdef __cplusplus
extern "C" {
#endif

// Game code (addresses as loaded in RAM)
void func_80107A30(uint8_t* rdram, recomp_context* ctx); // write one TLB entry (a0 = parameter block)
void func_80107AB8(uint8_t* rdram, recomp_context* ctx); // set the cache mode (Config)
void func_80107ADC(uint8_t* rdram, recomp_context* ctx); // flush both caches + set the cache mode
void func_80107BC4(uint8_t* rdram, recomp_context* ctx); // set the cache mode + flush the data cache
void func_80107B3C(uint8_t* rdram, recomp_context* ctx); // invalidate the data cache (cache ops)
void func_80107B80(uint8_t* rdram, recomp_context* ctx); // invalidate a cache range (cache ops)

// func_80100000 is the game's exception handler (in the function table because the vectors jump to it). The recomp never runs it:
// interrupts go through sams_irq_dispatch below.
void func_80100000(uint8_t* rdram, recomp_context* ctx);

// The exception handler func_80100000, interrupt path only. Call it instead of
// ReBuriki's func_800C2B20 in hw_events(): see BOOT_PLAN_sams64_2.md section 3.
void sams_irq_dispatch(uint8_t* rdram, recomp_context* ctx);

#ifdef __cplusplus
}
#endif

#endif
