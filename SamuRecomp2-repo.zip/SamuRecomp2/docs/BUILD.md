# Building SamuRecomp 2 (Samurai Shodown 64 2: Warriors Rage)

You build the game yourself, from ROM sets you own. Nothing below downloads or contains game data.

Tested on: Ubuntu 22.04 (a distrobox container on a Steam Deck works), Python 3.11, then run with Wine.
The compiled program is a Windows `.exe` (cross-compiled with llvm-mingw), so it also runs on Windows or with Proton.

## What you need

- `sams64_2.zip` and `hng64.zip` (MAME names; the unpack step finds files by checksum). `hng64.zip` must include
  `tmp87ph40an.bin` (the I/O board firmware).
- Ubuntu 22.04 with: `git cmake build-essential python3.11 curl xz-utils` (and, to test, `wine xvfb`).
- [N64Recomp](https://github.com/N64Recomp/N64Recomp) at commit `598ce20` (the version these scripts were tested
  with), built once:

```bash
git clone https://github.com/N64Recomp/N64Recomp ~/N64Recomp
cd ~/N64Recomp && git checkout 598ce20 && git submodule update --init --recursive
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build -j
ls build/N64Recomp          # must exist
```

## Steps

Run these from the repository folder (called `$REPO` here). Each command stops with a message if something is
wrong, and nothing is written half-way.

```bash
cd $REPO

# 1. take the files the port needs out of your ROM zips -> roms/sams64_2 and roms/hng64
python3 tools/sams64_2/unpack_roms_sams64_2.py --fork . --game ~/sams64_2.zip --bios ~/hng64.zip

# 2. translate the game's program to C (recomp/generated/, work/): derived from your ROM, never publish
python3.11 tools/sams64_2/translate_sams64_2.py --fork . --game ~/sams64_2.zip --n64recomp ~/N64Recomp

# 3. compile -> build/samurecomp.exe  (downloads llvm-mingw once into ~/llvm-mingw, about 200 MB)
python3.11 tools/sams64_2/build_sams64_2_linux.py --fork . --n64recomp ~/N64Recomp
```

The first build takes 10 to 30 minutes; a rebuild after changing one `.cpp` file is quick. If you update a runtime
file that an older build had replaced (for example a renamed `kernel_*.cpp`), delete the stale object in `build/obj/`.

## Run

```bash
export WINEPREFIX=$HOME/.wine-ss64 WINEDEBUG=-all
wine build/samurecomp.exe --roms roms --scale 2                       # window
xvfb-run -a wine build/samurecomp.exe --headless --no-sound --frames 6500 --roms roms \
    --dump-dir frames --dump-frames 2000,6000 \
    --input-script "1800=coin1;1804=;2100=p1start;2104=;2400=p1start;2404=;2700=p1start;2704="   # no screen
```

Options are listed at the top of `recomp/runtime/main.cpp`. Settings, controls and the arcade save memory are kept
next to the program (`settings.ini`, `controls.ini`, `nvram.bin`).

**Steam / Steam Deck (Proton):** add `build/samurecomp.exe` as a non-Steam game, force a Proton version, set the launch
options to `--roms /full/path/to/roms`, and choose the "Gamepad" controller template. The menu opens with Back + Start.

**Menu background:** put your own picture next to the program as `menu_art.png` (a real PNG or JPG; WebP is not
read). Do not commit it: it is not yours to redistribute.

## Notes on this game

- The memory map comes from the ROM's startup code: [BOOT_PLAN_sams64_2.md](BOOT_PLAN_sams64_2.md). Seven functions
  use CPU control instructions the translator cannot handle; they are listed in `tools/sams64_2/sams64_2.toml` and
  rewritten in `recomp/runtime/kernel_sams64_2.cpp` (`tests/test_kernel_sams64_2.cpp` checks them).
- `extract_sams64_2.py` patches one instruction in the *translated copy* of the code (`cfc1 $0` to `cfc1 $31`, an FPU
  context save); your ROM is never modified.
- `tools/sections.py` is this game's section table (the ReBuriki one is not used).

## Windows

`translate_sams64_2.py` runs on Windows too, but the compile step here is Linux cross-compilation. A native Windows
build and a `Setup.exe` like ReBuriki's still have to be adapted (ReBuriki's `tools/install` and
`tools/build_recomp.ps1` are the starting point).
