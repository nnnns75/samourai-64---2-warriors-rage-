# Warriors Rage (sams64_2): crt0 decoded (ROM 0x200-0x440)

Decoded from the ROM itself (`analyze_hng64_game.py --list 0x200 150`), cross-checked with the jal-target statistics.

| Step | Source (ROM) | Destination | Size |
|---|---|---|---|
| crt0 stub (run by the BIOS) | 0x200 | 0x80001000 | 0x1000 |
| copy 1 (data, includes gp area) | 0x510 | 0x802F2B10 | 0xB040 |
| copy 2 (game code + data) | 0xB550 | 0x80100000 | 0xC7130 (to 0x801C7130) |
| zero fill | - | 0x80200000..0x802F2B04 | 0xF2B04 |

- sp = 0x80008000 (lui 0x8001, -0x8000), **gp = 0x802F7FD8** (game 1: 0x8006CA90).
- Heuristic check: ROM 0x200 -> 0x800F4CB0 is the same mapping as copy 2 (ROM 0xB550 -> 0x80100000), 4525 prologue hits.
- Exception handler area 0x80000800 / 0x80000000..: copied from the stub (0x12E0, 0x12F8), same scheme as game 1.
- Kernel (COP0) candidates: 6, to be listed with `analyze_hng64_game.py` output (kernel_candidates.txt).

Next: write `extract_sams64_2.py` / `sections_sams64_2.py` / `sams64_2.toml` with this map, translate, build, boot.

## Update: extraction script (tools/sams64_2/extract_sams64_2.py)

- All exception vectors (0x80000000/80/180, and 0x80000800 after a runtime patch) are 5-word stubs `lui k0,0x8010; ori k0,0; jr k0`: **the game's exception handler is func_80100000** (first function of the game block; contains mfc0 Cause/EPC, eret). It must be hand-written in the runtime like game 1's handler.
- main = word at 0x802FB220 (gp+0x3248) = **0x8011D130**.
- Code range 0x80100000..0x8019ECF0 (3279 function seeds), data after it up to 0x801C7130, plus data block 0x802F2B10..0x802FDB50.
- Kernel (COP0/cache) candidates: func_80100000 (handler), func_80107A30 (TLB write), func_80107AB8, 80107ADC, 80107B3C, 80107B80, 80107BC4 (cache/Config).

## Update: translation works (tools/sams64_2/translate_sams64_2.py)

N64Recomp translates the game block: 3279 + 5 functions -> 33 C files. One ROM-copy patch is needed (extract_sams64_2.py PATCHES):
`cfc1 a1, $0` (FIR) at 0x80100EB0 in func_80100D3C (FPU context save) becomes `cfc1 a1, $31`; N64Recomp rejects FIR.
Not yet done: jump tables N64Recomp did not recognise (check "Indirect tail call" in func_8010F018 / func_8010FB38), hand-written exception handler and kernel functions (kernel_sams64_2.*), runtime adaptation (gp = 0x802F7FD8, main = 0x8011D130, hardware addresses), build.

## Update: kernel functions

The 6 hand-written kernel functions of game 1 are byte-for-byte the same SDK code in this game, at other addresses:
80107A30 (TLB write), 80107AB8 (cache mode), 80107ADC (flush both), 80107B3C / 80107B80 (cache ops), 80107BC4 (mode + flush).
`kernel_sams64_2.cpp/.h` are the game-1 versions renamed. The exception handler's interrupt path (func_80100000) is identical to game 1's
(IRQ level at 0xBF701104, handler table 0x80000400, counters 0x80000460), so `sams_irq_dispatch` is reused as is.

Still needed: the runtime's ROM loading (video.cpp scroll/sprite tiles, video3d.cpp textures/vertices, sound.cpp samples, hw.cpp program pairs)
is written for game 1's file names and layout. For this game: 8 program files (4 pairs?), 8 scroll files of 8 MB, sprites 4x8 MB + 4x4 MB,
4 sound files. The exact layout comes from MAME's ROM_START(sams64_2) in src/mame/snk/hng64.cpp.

## Update: runtime adapted (from MAME ROM_START(sams64_2))

- Program: 4 pairs (pr01+pr02 ... pr07+pr08) x 8 MB = 32 MB cart ROM.
- Scroll tiles 64 MB: sc01/sc02 @0, sc05/sc06 @0x1000000, sc03/sc04 @0x2000000, sc07/sc08 @0x3000000 (interleave 2).
- Sprites 64 MB: sp01-04 (8 MB each) @0 stride 4; sp05-08 (4 MB each) @0x2000000 stride 4.
- Textures 005tx01-04a.1-4 (first copy), vertices 005vt01-06, sound 005sd01-04 (4 x 4 MB).
- All loaders point to roms/sams64_2/. `kernel_sams64_2.*` replaces `kernel_sams64.*`; func_80100000 has a stub that aborts if ever called.
- Syntax-checked with clang on the Linux sandbox (kernel, hw, video3d, sound, main, function table, generated C); full build and first boot not done yet.

## Result: first boot (2026-11-27)

Build OK; headless run reaches the title ("Samurai Spirits 2"), character select, versus screen and a full fight (3D stages, rage gauge, timer) with no change to the vblank/palette handling inherited from game 1. Needed fixes: MEM_WU (lwu) in the runtime, `cfc1 $0` patch for N64Recomp, removal of game 1's kernel_sams64.* from the runtime.

## Fix: bottom of the fight screen cut (video3d.cpp)

Fights send projection packets with window words 10-13 = 0x100, -0x100, top 0x156..., bottom -0x6A... : a 512x448 window shifted up (off-centre frustum). The Buriki "how to play" viewport logic read it as a viewport and clipped 3D at buffer row ~377. A full-size window now uses the packet's own frustum values and no viewport (as MAME does).
